package itp341.hampson.lauren.growgirl.model;

import android.content.Context;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;
public class PlantSingleton {
    private static PlantSingleton singleton;
    private ArrayList<Plant> plants = new ArrayList<Plant>();
    private Context context;

    private PlantSingleton(Context context){
        this.context = context;
        plants = new ArrayList<>();

    }
    public static PlantSingleton get(Context context)
    {
        if(singleton == null)
        {
            singleton = new PlantSingleton(context);
        }
        return singleton;
    }
    public ArrayList<Plant> getPlants() {
        return plants;
    }
    public Plant getPlant(int position)
    {
        if (position >= 0 && position < plants.size()) {
            return plants.get(position);
        }
        else {
            return null;
        }
    }
    public void addPlant(Plant p) { // add is equivalent to save
        plants.add(p);
    }
// //   public void addComment(Movie m, String comment)
//    {
//        m.addComment(comment);
//    }
    public void removePlant(int position)  {
        plants.remove(position);
    }
    public void updatePlant(int position, Plant p) {
        // m = ms;
        plants.set(position, p);
    }
    public int plantCount()
    {
        return plants.size();
    }
}

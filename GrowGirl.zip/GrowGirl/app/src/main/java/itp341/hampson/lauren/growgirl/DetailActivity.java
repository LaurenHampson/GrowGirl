package itp341.hampson.lauren.growgirl;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

import itp341.hampson.lauren.growgirl.model.Plant;
import itp341.hampson.lauren.growgirl.model.PlantSingleton;

public class DetailActivity extends AppCompatActivity {

    TextView plantName;
    TextView plantDescription;
    TextView stateTitle;
    Plant p = new Plant("", "", "");
    PlantSingleton instance;
    int plantPos = 0;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);

        plantName = findViewById(R.id.plant_name);
        plantDescription = findViewById(R.id.plant_description);
        stateTitle = findViewById(R.id.state_label);
        Intent i = getIntent();
        instance = PlantSingleton.get(getApplicationContext());
        // final Movie m = (Movie)i.getSerializableExtra("Movie");

        int movPos = i.getIntExtra("Position", 1);
        p = instance.getPlant(movPos);


        plantName.setText(p.getName());
        plantDescription.setText(p.getDescription());
        stateTitle.setText(p.getLocation());


    }

}

package itp341.hampson.lauren.growgirl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.content.Context;
import android.content.Intent;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import android.widget.TextView;

import java.io.Serializable;
import java.util.List;


import itp341.hampson.lauren.growgirl.model.Plant;
import itp341.hampson.lauren.growgirl.model.PlantSingleton;

public class NativePlants extends AppCompatActivity implements Serializable {

    public static final String TAG = NativePlants.class.getSimpleName();

    private ListView listView;
    List<Plant> plants;
    PlantListAdapter plantListAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.native_plants);
        Intent i = getIntent();

        Plant p = (Plant)i.getSerializableExtra("Plant");


        listView = findViewById(R.id.listView);
        plants = PlantSingleton.get(this).getPlants();
        plantListAdapter = new PlantListAdapter(this, R.layout.layout_plant_list, plants);
        listView.setAdapter(plantListAdapter);






        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //removes from singleton
                PlantSingleton.get(getApplicationContext()).removePlant(position);
                //update screen
                plantListAdapter.notifyDataSetChanged();
                return false;
            }
        });
    }
    //TODO finish onActivityResult
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult: requestCode: " + requestCode);

        //in order to force android to redraw the data in the list, we must tell that the data changed
        plantListAdapter.notifyDataSetChanged();

    }
    private class PlantListAdapter extends ArrayAdapter<Plant>
    {
        public  PlantListAdapter(Context context, int resource, List<Plant> objects) {
            super(context, resource, objects);
        }


        //this method is what 1. creates all the row objects and 2. copies all model data to each row
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            //parent is the entire list view
            //convertView is ONE SINGLE row of the list
            if(convertView == null) // we have not created this row before AKA first time
            {
                //if it doesnt exist, then create of INFLATE the row from XML
                convertView = getLayoutInflater().inflate(R.layout.layout_plant_list, null);
            }

            // we inflate the row
            //we need a reference to EACH element in this row

            TextView textName = convertView.findViewById(R.id.list_item_name);

            final Button buttonView = convertView.findViewById(R.id.viewButton);




            Plant p = getItem(position);
            textName.setText(p.getName());

            buttonView.setTag(position);

//            //TODO add intent stuff to send this to the detail activity from inside the inflated view
            buttonView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int movPos = (Integer)buttonView.getTag();
                    Log.d(TAG, "mButtonView: onClick ");
                    Intent i = new Intent(getApplicationContext(), DetailActivity.class);

                    i.putExtra("Position", (Integer)buttonView.getTag());
                    startActivity(i);
                }
            });
            return convertView;


        }
    }
}


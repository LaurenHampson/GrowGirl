package itp341.hampson.lauren.growgirl;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

import java.io.Serializable;
import java.lang.annotation.Native;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import itp341.hampson.lauren.growgirl.model.Plant;
import itp341.hampson.lauren.growgirl.model.PlantSingleton;


public class MainActivity extends AppCompatActivity implements Serializable   {

    Spinner stateSpinner;
    Button plantButton;
    HashMap<String, Plant> plants = new HashMap<String, Plant>();
    Button selectButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stateSpinner = findViewById(R.id.state_spinner);
        plantButton = findViewById(R.id.plant_button);

        selectButton = findViewById(R.id.select_state);
        plantButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), InfoActivity.class);
                startActivity(i);
            }
        });


        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String state = stateSpinner.getSelectedItem().toString();
                instantiatePlants();


                Plant p = plants.get(state);

                Log.d("plant", p.toString());
                Intent i = new Intent(getApplicationContext(), NativePlants.class);
                Bundle b = new Bundle();
                b.putSerializable("Plant", p);

                i.putExtras(b);

                save(p);

                startActivity(i);
            }
        });

    }

    public void save(Plant p)
    {
        PlantSingleton.clear(this);
        PlantSingleton.get(this).addPlant(p);
    }
    private void instantiatePlants() {
        Plant a = new Plant("Aralia Spinosa (Devil’s Walking Stick)",
                "Devil’s Walking Stick is native to eastern North America. It reaches heights of 12-36 feet tall, and bears both fruits and flowers perennially.",
                "Alabama");
        plants.put("Alabama", a);

        a = new Plant("Aconitum Columbianum (Columbian Monkshood)",
             "Columbian Monkshoodis native to western North America. It reaches heights of 3-6 feet perennially.",
                "Alaska");
        plants.put("Alaska", a);

        a = new Plant("Abronia Villosa (Desert Sand Verbena)",
               "Desert Sand Verbena is native to the southwestern United States and northern Mexico. It reaches heights of <1 feet and bears flowers perennially.",
                "Arizona");
        plants.put("Arizona", a);

        a = new Plant("Andropogon Gerardii (Big Bluestem)", "Big Bluestem is native to the eastern and central grasslands of North America. It reaches heights of 4-8 feet and bears flowers perennially.",
                "Arkansas");
        plants.put("Arkansas", a);

        a = new Plant("Allium Unifolium (Oneleaf onion)",
                "Oneleaf onion is native to the mountainous ranges of western North America. It reaches heights of 1-3 feet and bears flowers perennially.",
                "California");
        plants.put("California", a);

        a = new Plant("Amelanchier Alnifolia (Saskatoon Serviceberry)", "Saskatoon Serviceberry is native to central Canada and the northern United States. It reaches heights of 3-6 feet and bears flowers perennially.",
                "Colorado");
        plants.put("Colorado", a);

        a = new Plant("Agastache Scrophyulariifolia (Purple Giant Hyssop)",
              "Purple Giant Hyssop is native to the United States and northern Ontario. It reaches heights of 3-6 feet and bears flowers perennially.",
                "Connecticut");
        plants.put("Connecticut", a);

        a = new Plant("Asclepias Tuberosa (Butterflyweed)", "Butterflyweed is native to eastern North America. It reaches heights of 1-3 feet and bears flowers perennially.",
                "Delaware");
        plants.put("Delaware", a);

        a = new Plant("Agarista Populifolia (Florida Hobblebush)", "Florida Hobblebush is native to the woodlands of the southeastern United States. It reaches heights of 6-12 feet and bears flowers perennially.",
                "Florida");
        plants.put("Florida", a);

        a = new Plant("Aesculus Parviflora (Bottlebrush Buckeye)", "Bottlebrush Buckeye is native to the southeastern United States. It reaches heights of 6-12 feet and bears flowers perennially.",
               "Georgia" );

        plants.put("Georgia", a);

        a = new Plant("Hibiscus Brackenridgei (Ma’o Hau Hele)", "Ma’o Hau Hele is the state flower of Hawai’i and is native to each of the islands. It reaches heights of 6-33 feet and bears flowers perennially.",
               "Hawaii" );
        plants.put("Hawaii", a);

        a = new Plant("Aquilegia Coerulea (Rocky Mountain Columbine)", "Rocky Mountain Columbine is native to the Rocky Mountains. It reaches heights of 1-3 feet and bears",
              "Idaho"  );

        plants.put("Idaho", a);

        a = new Plant("Actaea Rubra (Red Baneberry)", "Red Baneberry is native throughout North America. It reaches heights of 1-3 feet and bears both fruits and flowers perennially.",
                "Illinois");

        plants.put("Illinois", a);

        a = new Plant("Amorpha Canescens (Leadplant)", "Leadplant is native throughout North America. It reaches heights of 3-6 feet and bears flowers perennially.",
                "Indiana");
        plants.put("Indiana", a);

        a = new Plant("Aesculus Glabra (Horse Chestnut)", "Horse Chestnut is native in the midwestern and lower Great Plains regions of the United States. It reaches heights of 72-100 feet and bears flowers perennially.",
               "Iowa" );

        plants.put("Iowa", a);

        a = new Plant("Allium Stellatum (Autumn Onion)", "Autumn Onion is native to the midwestern United States. It reaches heights 1-2 feet and bears flowers perennially.",
                "Kansas");

        plants.put("Kansas", a);

        a = new Plant("Achillea Millefolium (Western Yarrow)", "Western Yarrow is native to temperate climates of the Northern Hemisphere, including North America, Europe, and Asia. It reaches heights of 1-3 feet and bears flowers perennially.",
                "Kentucky");

        plants.put("Kentucky", a);

        a = new Plant("Bignonia Capreolata (Crossvine)", "Crossvine is native to the central and southern regions of the United States. It reaches heights of 36-72 feet and bears flowers perennially.",
                "Louisiana");
        plants.put("Louisiana", a);

        a = new Plant("Amorpha Fruticosa (False Indigo)", "False Indigo is native to the central and eastern regions of the United States. It reaches heights of 6-12 feet and bears flowers perennially.",
                "Maine");
        plants.put("Maine", a);

        a = new Plant("Acer Pensylvanicum (Moosewood)", "Moosewood is native to the northeastern United States. It reaches heights of 36-72 feet perennially.",
                "Maryland");
        plants.put("Maryland", a);

        a = new Plant("Amelanchier Canadensis (Canadian Serviceberry)", "Canadian Serviceberry is native to eastern North America. It reaches heights of 36-72 feet and bears flowers perennially.",
                "Massachusetts");
        plants.put("Massachusetts", a);

        a = new Plant("Betula Nigra (River Birch)", "River Birch is native to the eastern and central United States. It reaches heights of 36-72 feet and bears flowers perennially.",
                "Michigan");

        plants.put("Michigan", a);

        a = new Plant("Anemone Canadensis (Windflower)", "Windflower is native to northern North America (especially Canada). It reaches heights 1-3 feet and bears flowers perennially.", "" +
                "Minnesota");

        plants.put("Minnesota", a);

        a = new Plant("Aronia Arbutifolia (Red Chokeberry)", "Red Chokeberry is native to eastern and central North America. It reaches heights of 6-12 feet and bears both fruits and flowers perennially.",
                "Mississippi");

        plants.put("Mississippi", a);

        a = new Plant("Catalpa Speciosa (Cigar Tree)", "Cigar Tree is native to the southeastern United States. It reaches heights of 72-100 feet and bears flowers perennially.",
                "Missouri");
        plants.put("Missouri", a);
        a = new Plant("Achnatherum Hymenoides (Indian Ricegrass)", "Indian Ricegrass is native to the western United States east of the Cascades. It reaches heights of 1-3 feet perennially.",
                "Montana");
        plants.put("Montana", a);

        a = new Plant("Campanulastrum Americanum (American Bellflower)", "American Bellflower is native to the Great Lakes region of the United States and Canada. It reaches heights of 3-6 feet and bears flowers annually.",
                "Nebraska");

        plants.put("Nebraska", a);

        a = new Plant("Abies Concolor (White Fir)", "White Fir is native to western North America it reaches heights of 36-72 feet perennially.",
                "Nevada");
        plants.put("Nevada", a);

        a = new Plant("Campsis Radicans (Hellvine)", "Hellvine is native to the eastern United States and naturalized to the western United States as well. It reaches heights of 12-36 feet and bears flowers perennially.",
                "New Hampshire");

        plants.put("New Hampshire", a);

        a = new Plant("Anaphalis Margaritacea (Pearly-everlasting)", "Pearly-everlasting is native to all of North America and parts of northern Mexico. It reaches heights of 1-3 feet and bears flowers perennially.",
                "New Jersey");

        plants.put("New Jersey", a);
        a = new Plant("Agave Parryi (Parry’s Agave)", "Parry’s Agave is native to the southern United States and northern Mexico. It reaches heights of 1-3 feet perennially.",
                "New Mexico");

        plants.put("New Mexico", a);

        a = new Plant("Asimina Triloba (Pawpaw)", "Pawpaw is native to eastern North America. It reaches heights of 12-36 feet and bears both fruit and flowers ",
                "New York");

        plants.put("New York", a);

        a = new Plant("Acer Negundo (Box Elder)", "Box Elder is native to North America. It reaches heights of 36-72 feet perennially.",
                "North Carolina");

        plants.put("North Carolina", a);

        a = new Plant("Zizia Aptera (Meadow Parsnip)", "Meadow Parsnip is native to eastern and central North America. It reaches heights of 1-3 feet and bears flowers perennially.",
                "North Dakota");

        plants.put("North Dakota", a);

        a = new Plant("Viburnum Acerifolium (Maple-leaf Arrowwood)", "Maple-leaf Arrowwood’s native range stretches from southwestern Canada to the eastern United States. It reaches heights of 6-12 feet and bears both fruits and flowers annually.",
                "Ohio");
        plants.put("Ohio", a);

        a = new Plant("Veronia Baldwinii (Ironweed)", "Ironweed is native to central North America. It reaches heights of 3-6 feet and bears flowers perennially.",
                "Oklahoma");
        plants.put("Oklahoma", a);

        a = new Plant("Abies Lasiocarpa (Subalpine Fir)", "Subalpine Fir is native to western North America. It reaches heights of 36-72 feet perennially.", "" +
                "Oregon");
        plants.put("Oregon", a);

        a = new Plant("Vaccinium Angustifolium (Lowbush Blueberry)", "Lowbush Blueberry is native to southern Canada and the northern United States. It reaches heights of 1-3 feet and bears both fruits and flowers annually.",
                "Pennsylvania");
        plants.put("Pennsylvania", a);

        a = new Plant("Vaccinium Corymbosum (Highbush Blueberry)", "Highbush Blueberry is native to eastern Canada and the eastern southern United States. It reaches heights of 6-12 feet and bears both fruits flowers perennially.",
                "Rhode Island");

        plants.put("Rhode Island", a);

        a = new Plant("Wisteria Frutescens (American Wisteria)", "American Wisteria is native to North America. It reaches heights of 12-36 feet and bears flowers perennially.",
                "South Carolina");

        plants.put("South Carolina", a);

        a = new Plant("Viburnum Ientago (Sheepberry)", "Sheepberry is native to southern Canada and the central United States. It reaches 12-36 feet and bears flowers perennially.",
                "South Dakota");

        plants.put("South Dakota", a);

        a = new Plant("Staphylea Trifolia (American Bladdernut)", "American Bladdernut is native to eastern North America. It reaches heights 12-36 feet and bears flowers perennially. ",
                "Tennessee");

        plants.put("Tennessee", a);

        a = new Plant("Ageratina Havanensis (White Mistflower)", "White Mistflower is native to the southern United States and northern Mexico. It reaches heights of 3-6 feet and bears flowers perennially.",
                "Texas");

        plants.put("Texas", a);
        a = new Plant("Acer Grandidentatum (Bigtooth Maple)", "Bigtooth Maple is native to the interior of western North America. It reaches heights of 36-72 feet perennially.",
                "Utah");


        plants.put("Utah", a);


        a = new Plant("Thuja Occidentalis (Arborvitae)", "Arborvitae is native to eastern Canada and the northeastern United States. It reaches heights of 72-100 feet perennially.",
                "Vermont");

        plants.put("Vermont", a);


        a = new Plant("Symphyotrichum Novae-Angliae (New England Aster)", "New England Aster is native to the eastern United States. It reaches heights of 3-6 feet and bears flowers perennially.",
                "Virginia");
        plants.put("Virginia", a);

        a = new Plant("Viola Glabella (Pioneer Violet)", "Pioneer Violet is native to northwestern North America. It reaches heights of <1 feet and bears flowers perennially.", "Washington" );

        plants.put("Washington", a);

        a = new Plant("Acer Negundo (Box Elder)", "Box Elder is native to southern Canada and the northern United States. It reaches heights of 36-72 feet perennially.", "West Virginia");
        plants.put("West Virginia", a);

        a = new Plant("Viola Pedata (Birdfoot Violet)", "Birdfoot Violet is native to central and eastern North America. It reaches heights of <1 feet and bears flowers perennially.", "Wisconsin");
        plants.put("Wisconsin", a);

        a = new Plant("Sorghastrum Nutans (Indiangrass)", "Indiangrass is found in the central United States, especially in the Great Plains. It reaches heights of 3-6 feet perennially.", "Wyoming");

        plants.put("Wyoming", a);


    }
}
